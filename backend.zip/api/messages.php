<?php
include 'connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $sql = "SELECT * FROM pesan WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo json_encode($result->fetch_assoc());
    } else {
        echo json_encode(["message" => "Record not found"]);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $sql = "SELECT * FROM pesan";
    $result = $conn->query($sql);

    $data = [];
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }

    echo json_encode($data);
}
include 'connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Membaca input JSON dari body request
    $input = file_get_contents('php://input');
    $data = json_decode($input, true); // Mengubah JSON menjadi array asosiatif

    // Cek apakah decoding berhasil
    if ($data !== null) {
        $ke = isset($data['ke']) ? $conn->real_escape_string($data['ke']) : '';
        $pengirim = isset($data['pengirim']) ? $conn->real_escape_string($data['pengirim']) : '';
        $pesan = isset($data['pesan']) ? $conn->real_escape_string($data['pesan']) : '';
        $musik = isset($data['musik']) ? $conn->real_escape_string($data['musik']) : '';

        // Pastikan tidak ada data yang kosong
        if (!empty($ke) && !empty($pesan) && !empty($musik)) {
            $sql = "INSERT INTO pesan (ke, pengirim, pesan, musik) VALUES ('$ke', '$pengirim', '$pesan', '$musik')";

            if ($conn->query($sql) === TRUE) {
                echo json_encode(["message" => "New record created successfully"]);
            } else {
                die(json_encode(["message" => "Error: " . $conn->error]));
            }
        } else {
            echo json_encode(["message" => "Error: Some fields are empty"]);
        }
    } else {
        echo json_encode(["message" => "Error: Invalid JSON input"]);
    }
}


?>
